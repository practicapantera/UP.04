# Медицинский центр «Медика» — учебный проект

Информационная система «Медицинский центр «Медика»» (УП.04, МДК.04.01).
Стек: Python 3.12, Django 5.1, Django REST Framework, JWT, PostgreSQL 16
(в учебном запуске используется SQLite, чтобы проект стартовал без установки СУБД).

## Запуск

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py loaddata demo   # или python manage.py seed
python manage.py runserver
```

Админка: http://127.0.0.1:8000/admin/ (логин `admin`, пароль `admin12345`).
API: http://127.0.0.1:8000/api/

## Модули

| Модуль | Назначение |
|---|---|
| accounts | пользователи и роли |
| catalog | специализация и услуга |
| clients | клиенты |
| orders | заказы и каскад статусов |
| reports | KPI и отчёты |
