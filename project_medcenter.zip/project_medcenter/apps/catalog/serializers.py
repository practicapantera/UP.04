from rest_framework import serializers

from .models import Specialization, Service


class SpecializationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Specialization
        fields = '__all__'


class ServiceSerializer(serializers.ModelSerializer):
    specialization = serializers.StringRelatedField()

    class Meta:
        model = Service
        fields = '__all__'
