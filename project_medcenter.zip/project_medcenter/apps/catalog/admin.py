from django.contrib import admin

from .models import Specialization, Service


@admin.register(Specialization)
class SpecializationAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)


@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('name', 'specialization', 'price', 'status')
    list_filter = ('status', 'specialization')
    search_fields = ('name',)
    list_editable = ('status',)
