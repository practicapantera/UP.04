from django.db import models


class Specialization(models.Model):
    name = models.CharField('Название', max_length=100, unique=True)

    class Meta:
        verbose_name = 'Специализация'
        verbose_name_plural = 'Специализацияы'
        ordering = ['name']

    def __str__(self):
        return self.name


class Service(models.Model):
    STATUS_CHOICES = [
        ('active', 'Доступна'),
        ('reserved', 'Забронирована'),
        ('archived', 'Архив'),
    ]

    specialization = models.ForeignKey(
        Specialization, on_delete=models.PROTECT,
        related_name='items', verbose_name='Специализация')
    name = models.CharField('Название', max_length=200)

    duration_min = models.PositiveIntegerField('Длительность, мин', default=30)

    price = models.DecimalField('Цена, руб.', max_digits=10, decimal_places=2)

    status = models.CharField('Статус', max_length=20, choices=STATUS_CHOICES, default='active')

    description = models.TextField('Описание', blank=True)

    class Meta:
        verbose_name = 'Услуга'
        verbose_name_plural = 'Услугаы'
        ordering = ['name']

    def __str__(self):
        return f'{self.name} ({self.specialization})'
