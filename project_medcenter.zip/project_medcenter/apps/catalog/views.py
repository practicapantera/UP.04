from rest_framework import viewsets

from .models import Specialization, Service
from .serializers import SpecializationSerializer, ServiceSerializer


class SpecializationViewSet(viewsets.ModelViewSet):
    queryset = Specialization.objects.all()
    serializer_class = SpecializationSerializer
    search_fields = ['name']


class ServiceViewSet(viewsets.ModelViewSet):
    queryset = Service.objects.select_related('specialization').all()
    serializer_class = ServiceSerializer
    search_fields = ['name']
