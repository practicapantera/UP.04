from rest_framework.routers import DefaultRouter

from .views import SpecializationViewSet, ServiceViewSet

router = DefaultRouter()
router.register('specializations', SpecializationViewSet)
router.register('services', ServiceViewSet)

urlpatterns = router.urls
