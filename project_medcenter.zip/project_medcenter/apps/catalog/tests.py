from django.test import TestCase
from rest_framework.test import APIClient

from apps.catalog.models import Specialization, Service


class CatalogApiTest(TestCase):
    def setUp(self):
        self.brand = Specialization.objects.create(name='Категория')
        Service.objects.create(
            specialization=self.brand, name='Позиция', price=500,
            )
        self.api = APIClient()

    def test_list_returns_200(self):
        response = self.api.get('/api/services/')
        self.assertEqual(response.status_code, 200)

    def test_list_contains_item(self):
        response = self.api.get('/api/services/')
        self.assertEqual(response.json()['count'], 1)
