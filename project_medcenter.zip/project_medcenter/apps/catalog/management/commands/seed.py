from django.core.management.base import BaseCommand
from django.utils import timezone

from apps.catalog.models import Specialization, Service
from apps.clients.models import Client
from apps.orders.models import Order
from apps.accounts.models import User


class Command(BaseCommand):
    help = 'Заполняет базу демонстрационными данными'

    def handle(self, *args, **options):
        for row in [('Терапия',), ('Диагностика',), ('Стоматология',)]:
            Specialization.objects.get_or_create(name=row[0], defaults={})

        for brand_name, name, extra in [
        ('Терапия', 'Приём терапевта', {'duration_min': 30, 'price': 2500}),
        ('Терапия', 'Профилактический осмотр', {'duration_min': 20, 'price': 1800}),
        ('Диагностика', 'УЗИ брюшной полости', {'duration_min': 40, 'price': 3200}),
        ('Диагностика', 'ЭКГ с расшифровкой', {'duration_min': 25, 'price': 1500}),
        ('Стоматология', 'Лечение кариеса', {'duration_min': 60, 'price': 6500}),
        ('Стоматология', 'Профессиональная чистка', {'duration_min': 45, 'price': 4800}),
        ]:
            brand = Specialization.objects.get(name=brand_name)
            Service.objects.get_or_create(
                name=name,
                defaults={'specialization': brand, **extra},
            )

        client, _ = Client.objects.get_or_create(
            last_name='Иванов', first_name='Иван',
            defaults={'phone': '+7-999-111-22-33', 'email': 'ivanov@mail.ru'})
        Client.objects.get_or_create(
            last_name='Петрова', first_name='Анна',
            defaults={'phone': '+7-999-222-33-44', 'email': 'petrova@mail.ru'})

        if not Order.objects.exists():
            Order.objects.create(client=client,
                                 service=Service.objects.first(),
                                 status='done', appointment_at=timezone.now())

        self.stdout.write(self.style.SUCCESS('Демо-данные загружены'))
