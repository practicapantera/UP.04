from django.db import models


class Client(models.Model):
    last_name = models.CharField('Фамилия', max_length=50)
    first_name = models.CharField('Имя', max_length=50)
    phone = models.CharField('Телефон', max_length=20)
    email = models.EmailField('Email', blank=True)

    birth_date = models.DateField('Дата рождения', null=True, blank=True)

    notes = models.TextField('Примечания', blank=True)

    created_at = models.DateTimeField('Дата регистрации', auto_now_add=True)

    class Meta:
        verbose_name = 'Клиент'
        verbose_name_plural = 'Клиенты'
        ordering = ['last_name', 'first_name']

    def __str__(self):
        return f'{self.last_name} {self.first_name}'

    @property
    def full_name(self):
        return f'{self.last_name} {self.first_name}'
