from rest_framework import serializers

from .models import Client


class ClientSerializer(serializers.ModelSerializer):
    full_name = serializers.ReadOnlyField()

    class Meta:
        model = Client
        fields = '__all__'
