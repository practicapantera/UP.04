from rest_framework import viewsets

from .models import Order
from .serializers import OrderSerializer


class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.select_related('client').all()
    serializer_class = OrderSerializer
    filterset_fields = ('status',)
