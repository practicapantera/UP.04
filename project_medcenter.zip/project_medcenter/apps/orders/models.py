from django.conf import settings
from django.db import models
from django.utils import timezone

from apps.catalog.models import Service
from apps.clients.models import Client


class Order(models.Model):
    STATUS_CHOICES = [
        ('new', 'Новая'),
        ('confirmed', 'Подтверждена'),
        ('done', 'Выполнена'),
        ('canceled', 'Отменена'),
    ]

    client = models.ForeignKey(Client, on_delete=models.CASCADE,
                               related_name='orders', verbose_name='Клиент')
    service = models.ForeignKey(
        Service, on_delete=models.PROTECT,
        related_name='orders', verbose_name='Услуга')
    staff = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                              null=True, blank=True, verbose_name='Врач')
    status = models.CharField('Статус', max_length=20, choices=STATUS_CHOICES, default='new')
    total = models.DecimalField('Сумма, руб.', max_digits=10, decimal_places=2, default=0)

    appointment_at = models.DateTimeField('Дата и время приёма', default=timezone.now)

    created_at = models.DateTimeField('Создан', auto_now_add=True)

    class Meta:
        verbose_name = 'Заказ'
        verbose_name_plural = 'Заказы'
        ordering = ['-created_at']

    def __str__(self):
        return f'Заказ №{self.pk} — {self.client}'

    def save(self, *args, **kwargs):
        if not self.total:
            self.total = self.service.price
        super().save(*args, **kwargs)
        item = self.service
        if self.status in ('new', 'confirmed') and item.status == 'active':
            item.status = 'reserved'
            item.save(update_fields=['status'])
        elif self.status == 'done' and item.status == 'reserved':
            item.status = 'archived'
            item.save(update_fields=['status'])
        elif self.status == 'canceled' and item.status == 'reserved':
            item.status = 'active'
            item.save(update_fields=['status'])
