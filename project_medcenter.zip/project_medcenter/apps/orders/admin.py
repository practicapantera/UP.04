from django.contrib import admin

from .models import Order


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'client', 'service', 'status', 'total', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('client__last_name', 'service__name')
    date_hierarchy = 'created_at'
    list_editable = ('status',)
