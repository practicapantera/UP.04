from django.test import TestCase

from apps.catalog.models import Specialization, Service
from apps.clients.models import Client
from apps.orders.models import Order


class OrderCascadeTest(TestCase):
    def setUp(self):
        brand = Specialization.objects.create(name='Тестовая группа')
        self.item = Service.objects.create(
            specialization=brand, name='Тестовая позиция', price=1000,
            )
        self.client = Client.objects.create(
            last_name='Тестов', first_name='Тест', phone='+7-000')

    def test_order_reserves_item(self):
        Order.objects.create(client=self.client, service=self.item)
        self.item.refresh_from_db()
        self.assertEqual(self.item.status, 'reserved')

    def test_done_order_archives_item(self):
        order = Order.objects.create(client=self.client, service=self.item)
        order.status = 'done'
        order.save()
        self.item.refresh_from_db()
        self.assertEqual(self.item.status, 'archived')

    def test_total_is_calculated(self):
        order = Order.objects.create(client=self.client, service=self.item)
        self.assertEqual(float(order.total), 1000.0)
