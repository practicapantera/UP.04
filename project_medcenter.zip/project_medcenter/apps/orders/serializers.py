from rest_framework import serializers

from .models import Order


class OrderSerializer(serializers.ModelSerializer):
    client_name = serializers.CharField(source='client.full_name', read_only=True)
    item_name = serializers.CharField(source='service.name', read_only=True)

    class Meta:
        model = Order
        fields = '__all__'
