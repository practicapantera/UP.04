from django.db.models import Avg, Count, Sum

from apps.orders.models import Order


def kpi():
    """Ключевые показатели системы."""
    done = Order.objects.filter(status='done')
    return {
        'orders_total': Order.objects.count(),
        'orders_done': done.count(),
        'revenue': float(done.aggregate(s=Sum('total'))['s'] or 0),
        'avg_check': float(done.aggregate(a=Avg('total'))['a'] or 0),
        'top_items': list(
            Order.objects.values('service__name')
            .annotate(cnt=Count('id'))
            .order_by('-cnt')[:5]
        ),
    }
