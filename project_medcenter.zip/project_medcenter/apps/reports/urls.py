from django.urls import path

from .views import KPIView

urlpatterns = [
    path('kpi/', KPIView.as_view(), name='kpi'),
]
